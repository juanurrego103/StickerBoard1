﻿namespace StickerBoard1
{
    partial class StickerBoard1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSticker = new System.Windows.Forms.ComboBox();
            this.nudX = new System.Windows.Forms.NumericUpDown();
            this.nudY = new System.Windows.Forms.NumericUpDown();
            this.nudSize = new System.Windows.Forms.NumericUpDown();
            this.pblLienzo = new System.Windows.Forms.PictureBox();
            this.pbColor = new System.Windows.Forms.PictureBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.btnCrear = new System.Windows.Forms.Button();
            this.txtContador = new System.Windows.Forms.TextBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pblLienzo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbColor)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbSticker
            // 
            this.cmbSticker.FormattingEnabled = true;
            this.cmbSticker.Location = new System.Drawing.Point(29, 23);
            this.cmbSticker.Name = "cmbSticker";
            this.cmbSticker.Size = new System.Drawing.Size(214, 24);
            this.cmbSticker.TabIndex = 0;
            // 
            // nudX
            // 
            this.nudX.Location = new System.Drawing.Point(29, 76);
            this.nudX.Name = "nudX";
            this.nudX.Size = new System.Drawing.Size(214, 22);
            this.nudX.TabIndex = 1;
            // 
            // nudY
            // 
            this.nudY.Location = new System.Drawing.Point(29, 120);
            this.nudY.Name = "nudY";
            this.nudY.Size = new System.Drawing.Size(214, 22);
            this.nudY.TabIndex = 2;
            // 
            // nudSize
            // 
            this.nudSize.Location = new System.Drawing.Point(29, 170);
            this.nudSize.Name = "nudSize";
            this.nudSize.Size = new System.Drawing.Size(120, 22);
            this.nudSize.TabIndex = 3;
            // 
            // PbLienzo
            // 
            this.pblLienzo.Location = new System.Drawing.Point(315, 23);
            this.pblLienzo.Name = "PbLienzo";
            this.pblLienzo.Size = new System.Drawing.Size(739, 452);
            this.pblLienzo.TabIndex = 4;
            this.pblLienzo.TabStop = false;
            // 
            // pbColor
            // 
            this.pbColor.Location = new System.Drawing.Point(167, 170);
            this.pbColor.Name = "pbColor";
            this.pbColor.Size = new System.Drawing.Size(27, 22);
            this.pbColor.TabIndex = 5;
            this.pbColor.TabStop = false;
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(29, 222);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(107, 46);
            this.btnCrear.TabIndex = 6;
            this.btnCrear.Text = "CREAR";
            this.btnCrear.UseVisualStyleBackColor = true;
            // 
            // txtContador
            // 
            this.txtContador.Location = new System.Drawing.Point(29, 302);
            this.txtContador.Name = "txtContador";
            this.txtContador.Size = new System.Drawing.Size(246, 22);
            this.txtContador.TabIndex = 7;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(167, 223);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(108, 45);
            this.btnLimpiar.TabIndex = 8;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // StickerBoard1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1164, 612);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.txtContador);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.pbColor);
            this.Controls.Add(this.pblLienzo);
            this.Controls.Add(this.nudSize);
            this.Controls.Add(this.nudY);
            this.Controls.Add(this.nudX);
            this.Controls.Add(this.cmbSticker);
            this.Name = "StickerBoard1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pblLienzo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbColor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSticker;
        private System.Windows.Forms.NumericUpDown nudX;
        private System.Windows.Forms.NumericUpDown nudY;
        private System.Windows.Forms.NumericUpDown nudSize;
        private System.Windows.Forms.PictureBox pblLienzo;
        private System.Windows.Forms.PictureBox pbColor;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.TextBox txtContador;
        private System.Windows.Forms.Button btnLimpiar;
    }
}

