﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using static StickerBoard1.StickerBoard1;

namespace StickerBoard1
{
    public class StickerCirculo : Sticker
    {
        public StickerCirculo(int x, int y, int size, Color color)
            : base(x, y, size, color) { }

        public override void Dibujar(Graphics g)
        {
            using (SolidBrush brush = new SolidBrush(Color))
            {
                g.FillEllipse(brush, X, Y, Size, Size);
            }
        }
    }
}
